// Warp & Dungeon Shortcuts for Hypixel SkyBlock
// Requires ChatTriggers
ChatLib.chat("&a[Warp Shortcuts] Script loaded!");

// ---- Warp Aliases ----
const warpAliases = {
    "forge": "warp forge",
    "dh": "warp dh",          // Dungeon Hub
    "hub": "warp hub",
    "is": "warp home",        // private island
    "island": "warp home",
    "ci": "warp crimson",
    "crimson": "warp crimson",
    "park": "warp park",
    "spider": "warp spider",
    "end": "warp end",
    "gold": "warp goldmine",
    "barn": "warp barn",
    "desert": "warp mushroom",
    "mushroom": "warp mushroom",
    "dwarven": "warp dwarven",
    "ch": "warp crystal",
    "crystal": "warp crystal",
    "dungeon": "warp dh"
};

// Properly register each warp alias
for (let alias in warpAliases) {
    ((aliasCopy) => {
        register("command", (...args) => {
            let extra = args.join(" ");
            if (extra.length > 0) {
                ChatLib.command(`${warpAliases[aliasCopy]} ${extra}`);
            } else {
                ChatLib.command(`${warpAliases[aliasCopy]}`);
            }
        }).setName(aliasCopy);
    })(alias);
}

// ---- Dungeon Floors (F1-F7, M1-M7) ----
const catacombsFloors = [
    "catacombs_floor_one",
    "catacombs_floor_two",
    "catacombs_floor_three",
    "catacombs_floor_four",
    "catacombs_floor_five",
    "catacombs_floor_six",
    "catacombs_floor_seven"
];

const masterFloors = [
    "master_catacombs_floor_one",
    "master_catacombs_floor_two",
    "master_catacombs_floor_three",
    "master_catacombs_floor_four",
    "master_catacombs_floor_five",
    "master_catacombs_floor_six",
    "master_catacombs_floor_seven"
];

// Properly bind F1-F7
for (let i = 0; i < catacombsFloors.length; i++) {
    ((floor, idx) => {
        // Normal floors
        register("command", (...args) => {
            let extra = args.join(" ");
            if (extra.length > 0) ChatLib.command(`joininstance ${floor} ${extra}`);
            else ChatLib.command(`joininstance ${floor}`);
        }).setName("f" + (idx + 1));

        // Master floors
        register("command", (...args) => {
            let extra = args.join(" ");
            if (extra.length > 0) ChatLib.command(`joininstance ${masterFloors[idx]} ${extra}`);
            else ChatLib.command(`joininstance ${masterFloors[idx]}`);
        }).setName("m" + (idx + 1));
    })(catacombsFloors[i], i);
}
